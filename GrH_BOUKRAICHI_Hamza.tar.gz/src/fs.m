function y = fs (x)
y = 2*pi^2 * sin ( pi * x(1)) * sin ( pi * x(2));
end